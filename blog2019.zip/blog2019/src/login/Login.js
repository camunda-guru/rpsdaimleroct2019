import React,{Component} from 'react'
import {Grid} from "@material-ui/core";
import {TextField} from "@material-ui/core";
import {Fab} from "@material-ui/core";
import PersonIcon from '@material-ui/icons/Person'
import axios from 'axios';
import './Login.css'
export class Login extends Component
{

    constructor(props)
    {
        super();
        this.state = {
            "userName":"",
            "password":""
        }

    }

    handleChange = input => e => {
        this.setState({ [input]: e.target.value });
    };



    submit=(e)=>{
        e.preventDefault();
        console.log(this.state);

        axios.get('http://localhost:6070/getuserbyname/'+this.state.userName)
            .then(res => {
                console.log(res.data);
                if(this.state.userName === res.data.userName)
                  window.location.href="/blog";
                else
                    window.location.href="/";
            });

    }


    render() {

        return(
            <form onSubmit={this.submit} style={{ backgroundColor: '#F0F0F0' }}  className="login" >
            <fieldset>
            <legend>Login</legend>
            <Grid container spacing={1}>
            <Grid item xs={12} sm={12}>
            <TextField
            id="userName"
             label="User Name"
             margin="normal"
        variant="outlined"
            onChange={this.handleChange("userName")}

            />
             </Grid>
            <Grid item xs={12} sm={12}>
            <TextField
            id="password"
            type ="password"
            label="Password"
            margin="normal"
        variant="outlined"
        onChange={this.handleChange("password")}
            />
            </Grid>

            </Grid>
            <Fab color="primary" aria-label="add" type="submit" >
            <PersonIcon />
            </Fab>
            </fieldset>

            </form>


        )

    }
}


