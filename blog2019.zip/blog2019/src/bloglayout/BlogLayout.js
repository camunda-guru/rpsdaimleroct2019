import React, { Component } from 'react';
import { Route } from 'react-router-dom';

const BlogLayout = ({children, ...rest}) => {
    return (
        <div className="page page-dashboard">

    <div className="main">{children}</div>
        </div>
)
}

const BlogLayoutRoute = ({component: Component, ...rest}) => {
    return (
        <Route {...rest} render={matchProps => (
    <BlogLayout>
    <Component {...matchProps} />
    </BlogLayout>
)} />
)
};

export default BlogLayoutRoute;
