import React from 'react'
import logoPath from '../assets/images/BlogLogo.jpg'
import './Logo.css'
//stateless component
const logo=()=>(
    <img src={logoPath} className="img" />
)


export default logo;

