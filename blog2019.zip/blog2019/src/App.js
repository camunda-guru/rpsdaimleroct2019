import React,{Component} from 'react';
import Logo from './logo/Logo'
import Title from './title/Title'
import {Login} from "./login/Login";
import {Menu} from "./menu/Menu";
import LoginLayoutRoute from "./loginlayout/LoginLayout";
import BlogLayoutRoute from './bloglayout/BlogLayout';
import { BrowserRouter as Router, Route, Redirect, Switch } from 'react-router-dom';
import './App.css';

/*function App() {
  return (
    <div className="App">

    </div>
  );
}*/
//stateful component
class App extends Component
{

  render() {
      return(
          <section >
          <header className="header">
           <Logo />
           <Title />
          </header>
          <article >
          <Router>
          <Switch>
          <Route exact path="/">
          <Redirect to="/home" />
          </Route>
          <LoginLayoutRoute path="/home" component={Login} />
      <BlogLayoutRoute path="/blog" component={Menu} />
      </Switch>
      </Router>
          </article>

          </section>

      )
  }
}





export default App;
