import React from 'react'
import './Title.css'
const title=()=>(
    <h4 className="title">Daimler Blog</h4>
)

export default title;
