import {Component, OnInit, Input, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-dashboard-feed',
  templateUrl: './dashboard-feed.component.html',
  styleUrls: ['./dashboard-feed.component.css']
})
export class DashboardFeedComponent implements OnInit {

  @Output('capitalize')
  private update=new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  updateData()
  {
    this.update.emit();
  }

}
