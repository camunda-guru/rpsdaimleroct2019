import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardFeedTitleComponent } from './dashboard-feed-title.component';

describe('DashboardFeedTitleComponent', () => {
  let component: DashboardFeedTitleComponent;
  let fixture: ComponentFixture<DashboardFeedTitleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardFeedTitleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardFeedTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
