import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-dashboard-feed-title',
  templateUrl: './dashboard-feed-title.component.html',
  styleUrls: ['./dashboard-feed-title.component.css']
})
export class DashboardFeedTitleComponent implements OnInit {
  @Input("titleData")
  private title:string;
  constructor() { }

  ngOnInit() {
  }

}
