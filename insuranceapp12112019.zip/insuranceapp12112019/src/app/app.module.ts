import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./services/menu.service";
import { PolicyComponent } from './policy/policy.component';
import { PolicyholderComponent } from './policyholder/policyholder.component';
import { VehicleComponent } from './vehicle/vehicle.component';
import { ReportComponent } from './report/report.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InboxComponent } from './inbox/inbox.component';
import {MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatTableModule,
  MatSortModule,
  MatPaginatorModule, MatDialogModule} from '@angular/material'

import {MenubarModule} from "primeng/menubar";
import {ChartModule} from 'primeng/chart';
import {MenuItem} from 'primeng/api';
import { AddPolicyComponent } from './policy/add-policy/add-policy.component';
import { EditPolicyComponent } from './policy/edit-policy/edit-policy.component';
import { ViewPolicyComponent } from './policy/view-policy/view-policy.component';
import { DeletePolicyComponent } from './policy/delete-policy/delete-policy.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {ButtonModule} from 'primeng/button';
import { AddPolicyHolderComponent } from './policyholder/add-policy-holder/add-policy-holder.component';
import { EditPolicyHolderComponent } from './policyholder/edit-policy-holder/edit-policy-holder.component';
import { ViewPolicyHolderComponent } from './policyholder/view-policy-holder/view-policy-holder.component';
import { DeletePolicyHolderComponent } from './policyholder/delete-policy-holder/delete-policy-holder.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import 'rxjs'
import {HttpClientModule} from "@angular/common/http";
import {AddPolicyHolderService} from "./services/add-policy-holder-service.service";
import { DashboardFeedComponent } from './dashboard/dashboard-feed/dashboard-feed.component';
import { DashboardFeedTitleComponent } from './dashboard/dashboard-feed-title/dashboard-feed-title.component';
@NgModule({
  declarations: [
    AppComponent,MenuComponent, PolicyComponent, PolicyholderComponent,
    VehicleComponent, ReportComponent, DashboardComponent, InboxComponent, AddPolicyComponent, EditPolicyComponent, ViewPolicyComponent,
    DeletePolicyComponent,
    AddPolicyHolderComponent,
    EditPolicyHolderComponent,
    ViewPolicyHolderComponent,
    DeletePolicyHolderComponent,
    DashboardFeedComponent,
    DashboardFeedTitleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatButtonModule,
    ButtonModule,
    MenubarModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatIconModule,
    HttpClientModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatDialogModule,
    ChartModule
  ],
  providers: [MenuService,AddPolicyHolderService],
  bootstrap: [AppComponent]
})
export class AppModule { }
