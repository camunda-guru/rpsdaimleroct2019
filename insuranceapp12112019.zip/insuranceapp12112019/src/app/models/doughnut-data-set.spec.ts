import { DoughnutDataSet } from './doughnut-data-set';

describe('DoughnutDataSet', () => {
  it('should create an instance', () => {
    expect(new DoughnutDataSet()).toBeTruthy();
  });
});
