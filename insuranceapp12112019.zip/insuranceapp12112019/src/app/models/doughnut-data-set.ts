export class DoughnutDataSet {

  private _data:number[];
  private _backgroudColor:string[];
  private _hoverBackgroundColor:string[];


  get data(): number[] {
    return this._data;
  }

  set data(value: number[]) {
    this._data = value;
  }

  get backgroudColor(): string[] {
    return this._backgroudColor;
  }

  set backgroudColor(value: string[]) {
    this._backgroudColor = value;
  }

  get hoverBackgroundColor(): string[] {
    return this._hoverBackgroundColor;
  }

  set hoverBackgroundColor(value: string[]) {
    this._hoverBackgroundColor = value;
  }
}
