import { DoughnutData } from './doughnut-data';

describe('DoughnutData', () => {
  it('should create an instance', () => {
    expect(new DoughnutData()).toBeTruthy();
  });
});
