import {DoughnutDataSet} from "./doughnut-data-set";

export class DoughnutData {
  private _labels:string[];
  private _datasets:DoughnutDataSet[];

  get datasets(): DoughnutDataSet[] {
    return this._datasets;
  }

  set datasets(value: DoughnutDataSet[]) {
    this._datasets = value;
  }

  get labels(): string[] {
    return this._labels;
  }

  set labels(value: string[]) {
    this._labels = value;
  }


}
