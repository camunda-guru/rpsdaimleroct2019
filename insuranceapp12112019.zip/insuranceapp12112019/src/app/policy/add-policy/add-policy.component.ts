import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-policy',
  templateUrl: './add-policy.component.html',
  styleUrls: ['./add-policy.component.css']
})
export class AddPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
