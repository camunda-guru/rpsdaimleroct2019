import { TestBed } from '@angular/core/testing';

import { AddPolicyHolderServiceService } from './add-policy-holder-service.service';

describe('AddPolicyHolderServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddPolicyHolderServiceService = TestBed.get(AddPolicyHolderServiceService);
    expect(service).toBeTruthy();
  });
});
