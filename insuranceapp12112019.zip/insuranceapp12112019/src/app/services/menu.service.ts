import {Injectable} from "@angular/core";
import {menuData} from '../models/menudata'
import {Menu} from '../models/menu'

@Injectable()
export class MenuService
{

  getMenuItems():Menu[]
  {
    return menuData;
  }


}
