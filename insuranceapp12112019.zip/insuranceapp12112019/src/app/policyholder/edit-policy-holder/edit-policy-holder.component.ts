import {Component, Inject, Injectable} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material';

@Component({
  selector: 'app-edit-policy-holder',
  templateUrl: './edit-policy-holder.component.html',
  styleUrls: ['./edit-policy-holder.component.css']
})
export class EditPolicyHolderComponent  {

  constructor(
    public dialogRef: MatDialogRef<EditPolicyHolderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any)
  {

  }

  onNoClick(): void {
    this.dialogRef.close();
  }



}
