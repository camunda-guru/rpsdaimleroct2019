import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPolicyHolderComponent } from './edit-policy-holder.component';

describe('EditPolicyHolderComponent', () => {
  let component: EditPolicyHolderComponent;
  let fixture: ComponentFixture<EditPolicyHolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPolicyHolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPolicyHolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
