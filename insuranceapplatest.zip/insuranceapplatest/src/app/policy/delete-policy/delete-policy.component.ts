import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-policy',
  templateUrl: './delete-policy.component.html',
  styleUrls: ['./delete-policy.component.css']
})
export class DeletePolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
