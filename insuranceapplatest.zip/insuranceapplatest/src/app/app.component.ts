import { Component } from '@angular/core';

@Component({
  selector: 'ins-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'insuranceapp';
  logoPath="./assets/globalinsurance.jpg";
}
