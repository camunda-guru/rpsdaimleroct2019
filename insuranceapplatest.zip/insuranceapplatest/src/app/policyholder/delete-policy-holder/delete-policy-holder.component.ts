import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-policy-holder',
  templateUrl: './delete-policy-holder.component.html',
  styleUrls: ['./delete-policy-holder.component.css']
})
export class DeletePolicyHolderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
