import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,FormBuilder,Validators} from "@angular/forms";

@Component({
  selector: 'app-add-policy-holder',
  templateUrl: './add-policy-holder.component.html',
  styleUrls: ['./add-policy-holder.component.css']
})
export class AddPolicyHolderComponent implements OnInit {

  adharCardNo:FormControl;
  firstName:FormControl;
  lastName:FormControl;
  email:FormControl;
  mobileNo:FormControl;
  policyHolder:FormGroup;

  constructor(private formBuilder:FormBuilder) {

   this.adharCardNo=new FormControl('',[Validators.required,
   Validators.pattern('[0-9]{12}')]);

   this.firstName=new FormControl('',[Validators.required,
     Validators.pattern('[a-zA-Z]{5,30}')]);

    this.lastName=new FormControl('',[Validators.required,
      Validators.pattern('[a-zA-Z]{5,30}')]);
    this.email=new FormControl('',[Validators.required,
      Validators.email]);
    this.mobileNo=new FormControl('',[Validators.required,
      Validators.pattern('[0-9]{10}')]);

     this.policyHolder=formBuilder.group({
       adharCardNo:this.adharCardNo,
       firstName:this.firstName,
       lastName:this.lastName,
       email:this.email,
       mobileNo:this.mobileNo

     })


  }

  ngOnInit() {
  }

}
