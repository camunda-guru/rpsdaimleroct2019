import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-policy-holder',
  templateUrl: './edit-policy-holder.component.html',
  styleUrls: ['./edit-policy-holder.component.css']
})
export class EditPolicyHolderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
