import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policyholder',
  templateUrl: './policyholder.component.html',
  styleUrls: ['./policyholder.component.css']
})
export class PolicyholderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
