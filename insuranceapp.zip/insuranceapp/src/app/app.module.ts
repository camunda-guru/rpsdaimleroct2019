import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./services/menu.service";
import { PolicyComponent } from './policy/policy.component';
import { PolicyholderComponent } from './policyholder/policyholder.component';
import { VehicleComponent } from './vehicle/vehicle.component';
import { ReportComponent } from './report/report.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InboxComponent } from './inbox/inbox.component';

@NgModule({
  declarations: [
    AppComponent,MenuComponent, PolicyComponent, PolicyholderComponent,
    VehicleComponent, ReportComponent, DashboardComponent, InboxComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [MenuService],
  bootstrap: [AppComponent]
})
export class AppModule { }
