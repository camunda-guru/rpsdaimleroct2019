import {Component,OnInit} from "@angular/core";
import {MenuService} from '../services/menu.service'
import {Menu} from '../models/menu'

@Component({
  selector:'ins-menu',
  templateUrl:'./menu.component.html',
  styleUrls:['./menu.component.css']
})
export class MenuComponent implements OnInit{

  private menuArr:any;

  //dependency injection
  constructor(private menuService:MenuService)
  {

  }

  ngOnInit(): void {

    this.menuArr=this.menuService.getMenuItems();
  }



}
