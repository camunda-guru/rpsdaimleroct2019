import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {InboxComponent} from "./inbox/inbox.component";
import {PolicyComponent} from "./policy/policy.component";
import {PolicyholderComponent} from "./policyholder/policyholder.component";
import {VehicleComponent} from "./vehicle/vehicle.component";
import {ReportComponent} from "./report/report.component";
import {DashboardComponent} from "./dashboard/dashboard.component";


const routes: Routes = [

  {
     path:'Inbox',
     component:InboxComponent
  },
  {
    path:'Policy',
    component:PolicyComponent
  },
  {
    path:'PolicyHolder',
    component:PolicyholderComponent
  },
  {
    path:'Vehicle',
    component:VehicleComponent
  },

  {
    path:'Report',
    component:ReportComponent
  },
  {
    path:'Dashboard',
    component:DashboardComponent


  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
