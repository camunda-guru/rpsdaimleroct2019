export class Menu
{
  private _menuId:number;
  private _menuName:string;


  constructor(menuId: number, menuName: string) {
    this._menuId = menuId;
    this._menuName = menuName;
  }

  get menuId(): number {
    return this._menuId;
  }

  set menuId(value: number) {
    this._menuId = value;
  }

  get menuName(): string {
    return this._menuName;
  }

  set menuName(value: string) {
    this._menuName = value;
  }


}
