import {Menu} from './menu'

export const menuData:Menu[]=[
  new Menu(1,'Inbox'),
  new Menu(2,'Policy'),
  new Menu(3,'PolicyHolder'),
  new Menu(4,'Vehicle'),
  new Menu(5,'Report'),
  new Menu(6,'Dashboard')
];
