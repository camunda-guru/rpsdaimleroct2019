export module ecommerce
{
export class Product
{
    private _productId:number;
    private _productName:string;
    private _active:boolean;

    get productId(): number {
        return this._productId;
    }

    set productId(value: number) {
        this._productId = value;
    }

    get productName(): string {
        return this._productName;
    }

    set productName(value: string) {
        this._productName = value;
    }

    get active(): boolean {
        return this._active;
    }

    set active(value: boolean) {
        this._active = value;
    }

    //private dop:new Date();
    constructor(id:number,name:string,active:boolean)
    {
        this._productId=id;
        this._productName=name;
        this._active=active;
    }




}

}
