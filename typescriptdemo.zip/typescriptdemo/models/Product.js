"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ecommerce;
(function (ecommerce) {
    var Product = /** @class */ (function () {
        //private dop:new Date();
        function Product(id, name, active) {
            this._productId = id;
            this._productName = name;
            this._active = active;
        }
        Object.defineProperty(Product.prototype, "productId", {
            get: function () {
                return this._productId;
            },
            set: function (value) {
                this._productId = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Product.prototype, "productName", {
            get: function () {
                return this._productName;
            },
            set: function (value) {
                this._productName = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Product.prototype, "active", {
            get: function () {
                return this._active;
            },
            set: function (value) {
                this._active = value;
            },
            enumerable: true,
            configurable: true
        });
        return Product;
    }());
    ecommerce.Product = Product;
})(ecommerce = exports.ecommerce || (exports.ecommerce = {}));
