"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Product_1 = require("../models/Product");
var product = new Product_1.ecommerce.Product(24858, "Mobile", true);
console.log("ProductId=" + product.productId + ",\nName=" + product.productName);
