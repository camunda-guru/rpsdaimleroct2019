import {ecommerce} from '../models/Product'


var product=new ecommerce.Product(24858,"Mobile",true);

console.log(`ProductId=${product.productId},
Name=${product.productName}`)
