//primitive types
var employeeId;
var empName;
var active;
var gender;
(function (gender) {
    gender[gender["MALE"] = 0] = "MALE";
    gender[gender["FEMALE"] = 1] = "FEMALE";
})(gender || (gender = {}));
employeeId = 327476;
empName = "George";
active = true;
var empGender;
empGender = gender.MALE;
console.log("Id=" + employeeId + ",Name=" + empName + ",\nStatus=" + active + ",Gender=" + gender[empGender]);
