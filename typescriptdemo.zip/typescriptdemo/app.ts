//primitive types
var employeeId:number;
var empName:string;
var active:boolean;
enum gender{
    MALE,FEMALE
}
employeeId=327476;
empName="George";
active=true;
var empGender:gender;
empGender=gender.MALE;
console.log(`Id=${employeeId},Name=${empName},
Status=${active},Gender=${gender[empGender]}`);


