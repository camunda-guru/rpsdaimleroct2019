package com.daimler.blogapp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="BlogUser")
@Getter
@Setter
public class User {
	@Id
	@Column(name="UserName")
	private String userName;
	@Column(name="Password",nullable = false,length = 15)
	private String password;
	
	

}
