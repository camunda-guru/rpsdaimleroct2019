package com.daimler.blogapp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daimler.blogapp.models.User;
import com.daimler.blogapp.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	public User findByUserName(String userName)
	{
		return userRepository.findById(userName).orElse(null);
	}
	
}
