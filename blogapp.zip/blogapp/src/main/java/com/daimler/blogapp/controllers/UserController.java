package com.daimler.blogapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.daimler.blogapp.models.User;
import com.daimler.blogapp.services.UserService;

@RestController
public class UserController {
    @Autowired    
	private UserService userService;
	
    @CrossOrigin("*")
	@GetMapping("/getuserbyname/{userName}")
	public User getUserByName(@PathVariable("userName") String userName)
	{
		return userService.findByUserName(userName);
	}
	
	
}
