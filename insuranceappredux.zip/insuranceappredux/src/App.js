import React,{Component} from 'react';
import Logo from './Logo/logo'
import Menu from './Menu/menu.jsx'
import './App.css';

//ReactComponent
class App extends Component
{

    constructor(props)
    {
        super(props);
        this.state={
            date:new Date(),
            menuItems:[
                {
                    name:'PolicyHolder'
                },
                {
                    name:'Vehicle'
                },
                {
                    name:'Driver'
                },
                {
                    name:'LossInfo'
                }

            ]
        }

    }


    componentDidMount() {

      this.timerId=setInterval(()=>this.tick(),1000)

    }


    componentWillMount() {
        clearInterval(this.timerId);
    }

    tick()
    {
        //update the state
        this.setState({
            date:new Date()
        })
    }


    render() {
        return(
            <div className="App">
              <header>
              <Logo/>
              <h4 className="title">Auto Insurance Claim Life Cycle Management</h4>
              <h4 >{this.state.date.toLocaleTimeString()}</h4>
               </header>
               <section>
               <Menu items={this.state.menuItems} />
              </section>

        </div>
        )

    }
}



export default App;
