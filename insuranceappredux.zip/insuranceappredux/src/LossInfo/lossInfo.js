import React,{Component} from 'react'

class LossInfo extends Component
{

    render()
    {
        return(
            <h4>LossInfo</h4>
    )
    }
}

export default LossInfo
