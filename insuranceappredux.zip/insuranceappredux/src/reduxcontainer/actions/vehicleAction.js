import * as actionTypes from './actionType';
import axios from 'axios';

const apiUrl = 'http://localhost:4000/vehicles';
/*
createContact() function returns an object that describes two things.

action type
payload
 */
/*export const createVehicle = (vehicle) => {
    return {
        type: actionTypes.CREATE_NEW_VEHICLE,
        vehicle: vehicle
    }
};*/


export const createVehicle = (vehicle) => {
    return (dispatch) => {
        return axios.post(`${apiUrl}/add`, vehicle)
            .then(response => {
                dispatch(createVehicleSuccess(response.data))
            })
            .catch(error => {
                throw(error);
            });
    };
};

export const createVehicleSuccess =  (data) => {
    return {
        type: actionTypes.CREATE_NEW_VEHICLE,
        vehicle: data
    }
};




export const deleteVehicleSuccess = (id) => {
    return {
        type: actionTypes.REMOVE_VEHICLE,
        id: {
            id
        }
    }
}

export const deleteVehicle = (id) => {
    return (dispatch) => {
        return axios.get(`${apiUrl}/delete/${id}`)
            .then(response => {
                console.log(response);
                dispatch(deleteVehicleSuccess(response.data))
            })
            .catch(error => {
                throw(error);
            });
    };
};





/*
export const deleteVehicle = (id) => {
    return {
        type: actionTypes.REMOVE_VEHICLE,
        id: id
    }
}*/
