import React from 'react'
import{BrowserRouter,Switch,NavLink,Route} from 'react-router-dom'
import './menu.css'
import {PolicyHolder} from '../PolicyHolder/policyholder'
import Driver from '../Driver/driver'
import LossInfo from '../LossInfo/lossInfo'
import Vehicle from '../Vehicle/vehicle'

//stateless component
const menu=(props)=>(
    <BrowserRouter basename={"/insuranceapp"}>
      <ul>
      {
        props.items.map(item=>(

            <li key={item.name} className='menu'>
             <NavLink activeClassName='is-active' className='link-text'
                      to={item.name}>{item.name}</NavLink>
             </li>
            )

        )

    }

    </ul>
    <Switch>
       <Route path={"/PolicyHolder"} component={PolicyHolder}/>
        <Route path={"/Driver"} component={Driver}/>
        <Route path={"/LossInfo"} component={LossInfo}/>
        <Route path={"/Vehicle"} component={Vehicle}/>
    </Switch>
</BrowserRouter>
)

export default menu;


