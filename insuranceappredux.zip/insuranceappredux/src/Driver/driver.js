import React,{Component} from 'react'

class Driver extends Component
{

    render()
    {
        return(
            <h4>Driver</h4>
    )
    }
}

export default Driver
