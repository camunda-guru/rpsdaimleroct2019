import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./services/menu.service";
import { PolicyComponent } from './policy/policy.component';
import { PolicyholderComponent } from './policyholder/policyholder.component';
import { VehicleComponent } from './vehicle/vehicle.component';
import { ReportComponent } from './report/report.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InboxComponent } from './inbox/inbox.component';
import {MatButtonModule} from '@angular/material'

import {MenubarModule} from "primeng/menubar";
import {MenuItem} from 'primeng/api';
import { AddPolicyComponent } from './policy/add-policy/add-policy.component';
import { EditPolicyComponent } from './policy/edit-policy/edit-policy.component';
import { ViewPolicyComponent } from './policy/view-policy/view-policy.component';
import { DeletePolicyComponent } from './policy/delete-policy/delete-policy.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {ButtonModule} from 'primeng/button';
import { AddPolicyHolderComponent } from './policyholder/add-policy-holder/add-policy-holder.component';
import { EditPolicyHolderComponent } from './policyholder/edit-policy-holder/edit-policy-holder.component';
import { ViewPolicyHolderComponent } from './policyholder/view-policy-holder/view-policy-holder.component';
import { DeletePolicyHolderComponent } from './policyholder/delete-policy-holder/delete-policy-holder.component';
@NgModule({
  declarations: [
    AppComponent,MenuComponent, PolicyComponent, PolicyholderComponent,
    VehicleComponent, ReportComponent, DashboardComponent, InboxComponent, AddPolicyComponent, EditPolicyComponent, ViewPolicyComponent,
    DeletePolicyComponent,
    AddPolicyHolderComponent,
    EditPolicyHolderComponent,
    ViewPolicyHolderComponent,
    DeletePolicyHolderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatButtonModule,
    ButtonModule,
    MenubarModule,

    BrowserAnimationsModule,

  ],
  providers: [MenuService],
  bootstrap: [AppComponent]
})
export class AppModule { }
