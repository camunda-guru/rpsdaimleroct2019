import {Component,OnInit,Input} from "@angular/core";
import {MenuService} from '../services/menu.service'
import {Menu} from '../models/menu'
import {Router} from '@angular/router';
@Component({
  selector:'ins-menu',
  templateUrl:'./menu.component.html',
  styleUrls:['./menu.component.css']
})
export class MenuComponent implements OnInit{

  private _menuArr:any;

  //dependency injection
  constructor(private menuService:MenuService,private router: Router)
  {

  }

  ngOnInit(): void {

    this._menuArr=this.menuService.getMenuItems();
  }



}
