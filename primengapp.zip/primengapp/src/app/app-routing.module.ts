import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {InboxComponent} from "./inbox/inbox.component";
import {PolicyComponent} from "./policy/policy.component";
import {PolicyholderComponent} from "./policyholder/policyholder.component";
import {VehicleComponent} from "./vehicle/vehicle.component";
import {ReportComponent} from "./report/report.component";
import {DashboardComponent} from "./dashboard/dashboard.component";
import {AddPolicyComponent} from "./policy/add-policy/add-policy.component";
import {EditPolicyComponent} from "./policy/edit-policy/edit-policy.component";
import {ViewPolicyComponent} from "./policy/view-policy/view-policy.component";
import {DeletePolicyComponent} from "./policy/delete-policy/delete-policy.component";
import {AddPolicyHolderComponent} from "./policyholder/add-policy-holder/add-policy-holder.component";
import {EditPolicyHolderComponent} from "./policyholder/edit-policy-holder/edit-policy-holder.component";
import {ViewPolicyHolderComponent} from "./policyholder/view-policy-holder/view-policy-holder.component";
import {DeletePolicyHolderComponent} from "./policyholder/delete-policy-holder/delete-policy-holder.component";


const routes: Routes = [

  {
     path:'Inbox',
     component:InboxComponent
  },
  {
    path: 'Policy',
    component: PolicyComponent,
    children: [
      {path: 'Add', component: AddPolicyComponent},
      {path: 'Edit', component: EditPolicyComponent},
      {path: 'View', component: ViewPolicyComponent},
      {path: 'Delete', component: DeletePolicyComponent}

    ]

  }
  ,
  {
    path:'PolicyHolder',
    component:PolicyholderComponent,
    children: [
      {path: 'Add', component: AddPolicyHolderComponent},
      {path: 'Edit', component: EditPolicyHolderComponent},
      {path: 'View', component: ViewPolicyHolderComponent},
      {path: 'Delete', component: DeletePolicyHolderComponent}

    ]
  },
  {
    path:'Vehicle',
    component:VehicleComponent
  },

  {
    path:'Report',
    component:ReportComponent
  },
  {
    path:'Dashboard',
    component:DashboardComponent


  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
