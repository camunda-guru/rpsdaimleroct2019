import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-policy-holder',
  templateUrl: './add-policy-holder.component.html',
  styleUrls: ['./add-policy-holder.component.css']
})
export class AddPolicyHolderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
