import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-policy-holder',
  templateUrl: './view-policy-holder.component.html',
  styleUrls: ['./view-policy-holder.component.css']
})
export class ViewPolicyHolderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
